print("Encrypt AI Aimbot is currently unavailable. We will be back soon!")
